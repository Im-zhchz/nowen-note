import "./chunks/modulepreload-polyfill-DaKOjhqt.js";
import { g as getConfig, i as isConfigured, s as setConfig, n as normalizeBaseUrl } from "./chunks/storage-DiurM1t3.js";
async function init() {
  const cfg = await getConfig();
  const elNot = document.getElementById("not-configured");
  const elMain = document.getElementById("main");
  const elServer = document.getElementById("server-preview");
  if (!isConfigured(cfg)) {
    elNot.classList.remove("hidden");
    elMain.classList.add("hidden");
    document.getElementById("open-options").addEventListener("click", () => {
      chrome.runtime.openOptionsPage();
    });
    return;
  }
  elServer.textContent = shortUrl(cfg.serverUrl);
  document.getElementById("notebook").value = cfg.defaultNotebook || "";
  document.getElementById("tags").value = cfg.defaultTags || "";
  document.getElementById("quick-capture").checked = cfg.quickCapture || false;
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab?.title) {
      const titleEl = document.getElementById("page-title");
      titleEl.textContent = tab.title;
      titleEl.title = tab.title;
    }
  } catch {
  }
  document.getElementById("quick-capture").addEventListener("change", async (e) => {
    const checked = e.target.checked;
    await setConfig({ quickCapture: checked });
  });
  document.getElementById("clip").addEventListener("click", clip);
  document.getElementById("open-options-footer").addEventListener("click", (e) => {
    e.preventDefault();
    chrome.runtime.openOptionsPage();
  });
}
async function clip() {
  const btn = document.getElementById("clip");
  const progress = document.getElementById("progress");
  const progressText = document.getElementById("progress-text");
  const resultEl = document.getElementById("result");
  resultEl.classList.add("hidden");
  progress.classList.remove("hidden");
  progressText.textContent = "准备中...";
  btn.disabled = true;
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) {
    showResult(false, "未找到当前标签页");
    btn.disabled = false;
    progress.classList.add("hidden");
    return;
  }
  const mode = document.getElementById("clip-mode").value;
  const comment = document.getElementById("comment").value.trim();
  console.log("[nowen-clipper popup] 选择的模式:", mode);
  const req = {
    type: "CLIP_REQUEST",
    mode,
    tabId: tab.id,
    overrideNotebook: document.getElementById("notebook").value.trim(),
    overrideTags: document.getElementById("tags").value.trim(),
    comment: comment || void 0
  };
  if (mode === "screenshot" || mode === "fullScreenshot") {
    progressText.textContent = "正在准备截图，popup 即将关闭...";
    chrome.runtime.sendMessage(req).catch(() => {
    });
    setTimeout(() => window.close(), 100);
    return;
  }
  const handler = (msg) => {
    if (msg?.type !== "CLIP_PROGRESS") return;
    progressText.textContent = msg.message;
  };
  chrome.runtime.onMessage.addListener(handler);
  try {
    const res = await chrome.runtime.sendMessage(req);
    progress.classList.add("hidden");
    if (res?.ok) {
      const imgInfo = res.images ? `图片 ${res.images.ok} 张${res.images.failed ? `（${res.images.failed} 张失败）` : ""}` : "";
      showResult(true, `✅ 已剪藏：「${res.noteTitle || "无标题"}」${imgInfo ? "，" + imgInfo : ""}`);
    } else {
      showResult(false, `❌ ${res?.error || "未知错误"}`);
    }
  } catch (e) {
    progress.classList.add("hidden");
    showResult(false, `❌ ${String(e?.message || e)}`);
  } finally {
    chrome.runtime.onMessage.removeListener(handler);
    btn.disabled = false;
  }
}
function showResult(ok, text) {
  const el = document.getElementById("result");
  el.classList.remove("hidden", "ok", "err");
  el.classList.add(ok ? "ok" : "err");
  el.textContent = text;
}
function shortUrl(u) {
  try {
    const x = new URL(normalizeBaseUrl(u));
    return x.host;
  } catch {
    return u;
  }
}
void init();
